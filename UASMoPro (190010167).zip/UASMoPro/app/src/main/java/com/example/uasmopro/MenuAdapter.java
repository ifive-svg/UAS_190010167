package com.example.uasmopro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.BreakIterator;
import java.util.ArrayList;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {
    private Context context;
    private ArrayList<Menu> menus;

    public MenuAdapter(Context mcontext,ArrayList<Menu> menuhp){
        context=mcontext;
        menus=menuhp;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_menu,parent,false);

        return new MenuViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        Menu menubaru=menus.get(position);
        String gambarbaru=menubaru.getGambar();
        String harga=menubaru.getHarga();
        String nama=menubaru.getNama();
        String deskripsi=menubaru.getDeskripsi();

        holder.tvnamadata.setText(nama);
        holder.tvhargadata.setText(harga);
        holder.tvdeskripsi.setText(deskripsi);
        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.imdata);
        holder.btpesan.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent pindah=new Intent(v.getContext(),Detail_Activity.class);
                pindah.putExtra("nama", menubaru.getNama());
                pindah.putExtra("harga", menubaru.getHarga());
                pindah.putExtra("deskripsi", menubaru.getDeskripsi());
                pindah.putExtra("gambar", menubaru.getGambar());
                v.getContext().startActivity(pindah);

            }
        });
    }

    @Override
    public int getItemCount() {
        return menus.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder{
        public Button btpesan;
        public ImageView imdata;
        public TextView tvhargadata;
        public TextView tvnamadata;
        public TextView tvdeskripsi;


        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata=itemView.findViewById(R.id.img_menu);
            tvhargadata=itemView.findViewById(R.id.tv_harga);
            tvnamadata=itemView.findViewById(R.id.tv_nama);
            tvdeskripsi=itemView.findViewById(R.id.tv_keterangan);
            btpesan=itemView.findViewById(R.id.btn_pesan);

        }
    }
}
