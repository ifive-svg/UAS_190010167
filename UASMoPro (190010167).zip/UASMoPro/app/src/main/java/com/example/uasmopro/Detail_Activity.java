package com.example.uasmopro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class Detail_Activity extends AppCompatActivity implements View.OnClickListener {
    TextView tvnamahp,tvharga,tvdesk,tvorder;
    ImageView imhp;
    Button BtOrder;

    public static final String Menu = "menu";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail2);

        tvnamahp = findViewById(R.id.tvNamaHp);
        tvnamahp.setText(getIntent().getStringExtra("nama"));

        tvharga = findViewById(R.id.tvHarga);
        tvharga.setText(getIntent().getStringExtra("harga"));

        tvdesk = findViewById(R.id.tvDeskripsi);
        tvdesk.setText(getIntent().getStringExtra("deskripsi"));

        imhp = findViewById(R.id.ivHp);
        String url = getIntent().getStringExtra("gambar");
        Glide.with(this)
                .load(url)
                .apply(new RequestOptions())
                .override(700, 700)
                .into(imhp);
        tvorder=findViewById(R.id.order);

        BtOrder=findViewById(R.id.btorder);
        BtOrder.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

    }
}
