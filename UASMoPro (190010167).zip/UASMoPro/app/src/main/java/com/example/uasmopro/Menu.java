package com.example.uasmopro;

public class Menu {
    private String nama;
    private String harga;
    private String gambar;
    private String deskripsi;

    public Menu(String datanama, String dataharga, String datagambar, String datadesk) {
        nama = datanama;
        harga = dataharga;
        gambar = datagambar;
        deskripsi = datadesk;

    }

    public String getNama() {
        return nama;
    }

    public String getHarga() {
        return harga;
    }

    public String getGambar() {
        return gambar;
    }

    public String getDeskripsi() {return deskripsi; }
}

